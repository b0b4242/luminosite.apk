package com.jp.luminosite.remote

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.util.concurrent.Executors

/**
 * Télécommande : envoie des commandes à l'app « Luminosité » de la Fire Stick
 * par ADB sur le réseau Wi-Fi (broadcast vers ControlReceiver).
 */
class MainActivity : Activity() {

    companion object {
        private val ACCENT = 0xFFFFB347.toInt()
        private val DARK_TEXT = 0xFF14110D.toInt()
        private val MUTED = 0x99FFFFFF.toInt()
        private val ERROR = 0xFFFF6B6B.toInt()
        private val TINTS = arrayOf("ambre", "sépia", "rouge", "miel")
        private val DURATIONS = intArrayOf(15, 30, 45, 60, 90)
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    // File d'attente de commandes : la plus récente d'un même type remplace l'ancienne
    private val pending = LinkedHashMap<String, String>()
    private var running = false
    private var adb: Dadb? = null
    private var connectedHost: String? = null
    @Volatile
    private var currentHost = ""

    private lateinit var statusView: TextView
    private lateinit var hostInput: EditText
    private lateinit var brightnessText: TextView
    private lateinit var brightnessSeek: SeekBar
    private lateinit var nightSwitch: Switch
    private lateinit var warmthText: TextView
    private lateinit var warmthSeek: SeekBar
    private val tintButtons = ArrayList<TextView>()
    private val durationButtons = ArrayList<TextView>()

    private var brightness = 100
    private var tint = 0
    private var duration = 30
    private var updating = false
    private var dragging = false
    private var lastSent = 0L

    // ---------- Petits utilitaires d'interface ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun label(s: String, sp: Float, color: Int, light: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (light) typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(16), dp(20), dp(18))
        background = rounded(0x14FFFFFF, 24, 0x1FFFFFFF)
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
    }

    private fun pill(text: String, onClick: () -> Unit): TextView =
        label(text, 16f, Color.WHITE).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(0x26FFFFFF, 20)
            isClickable = true
            setOnClickListener { onClick() }
        }

    private fun select(v: TextView, on: Boolean) {
        v.background = rounded(if (on) ACCENT else 0x26FFFFFF, 20)
        v.setTextColor(if (on) DARK_TEXT else Color.WHITE)
    }

    private fun equalRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
    }

    private fun addEqual(row: LinearLayout, v: TextView) {
        row.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
            marginStart = dp(4)
            marginEnd = dp(4)
        })
    }

    private fun seek(max: Int, onChange: (Int, Boolean) -> Unit): SeekBar = SeekBar(this).apply {
        this.max = max
        progressTintList = ColorStateList.valueOf(ACCENT)
        thumbTintList = ColorStateList.valueOf(ACCENT)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p, false)
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                dragging = false
                onChange(s.progress, true)
            }
        })
    }

    private fun setStatus(text: String, error: Boolean) {
        statusView.text = text
        statusView.setTextColor(if (error) ERROR else MUTED)
    }

    // ---------- Construction de l'écran ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentHost = getSharedPreferences("remote", MODE_PRIVATE).getString("host", "") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        root.addView(label("LUMINOSITÉ TV", 13f, MUTED).apply { letterSpacing = 0.25f })
        root.addView(label("Télécommande", 30f, Color.WHITE, true))
        statusView = label("", 14f, MUTED).apply { setPadding(0, dp(6), 0, 0) }
        root.addView(statusView)

        // Connexion
        val conn = card()
        conn.addView(label("FIRE STICK", 12f, ACCENT).apply { letterSpacing = 0.2f })
        hostInput = EditText(this).apply {
            hint = "Adresse IP (ex. 192.168.1.50)"
            setHintTextColor(0x66FFFFFF)
            setTextColor(Color.WHITE)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            setText(currentHost)
        }
        conn.addView(hostInput)
        val connRow = equalRow()
        addEqual(connRow, pill("Connecter") { connect() })
        conn.addView(connRow)
        root.addView(conn)

        // Luminosité
        val bc = card()
        bc.addView(label("LUMINOSITÉ", 12f, ACCENT).apply { letterSpacing = 0.2f })
        brightnessText = label("—", 64f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        bc.addView(brightnessText, LinearLayout.LayoutParams(MATCH, WRAP))
        brightnessSeek = seek(95) { p, final ->
            val b = p + 5
            brightness = b
            brightnessText.text = "$b %"
            throttled(final) { queue("b", "--ei brightness $b") }
        }
        bc.addView(brightnessSeek, LinearLayout.LayoutParams(MATCH, WRAP))
        val stepRow = equalRow()
        for (d in intArrayOf(-5, -1, 1, 5)) {
            addEqual(stepRow, pill(if (d > 0) "+$d" else "$d") { step(d) })
        }
        bc.addView(stepRow)
        root.addView(bc)

        // Mode nuit
        val nc = card()
        nc.addView(label("MODE NUIT", 12f, ACCENT).apply { letterSpacing = 0.2f })
        nightSwitch = Switch(this).apply {
            text = "Mode nuit"
            textSize = 18f
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                if (!updating) queue("n", "--ei night ${if (checked) 1 else 0}")
            }
        }
        nc.addView(nightSwitch, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        warmthText = label("Chaleur 50 %", 16f, Color.WHITE).apply { setPadding(0, dp(12), 0, 0) }
        nc.addView(warmthText)
        warmthSeek = seek(19) { p, final ->
            val w = (p + 1) * 5
            warmthText.text = "Chaleur $w %"
            setNightChecked(true)
            throttled(final) { queue("w", "--ei warmth $w --ei night 1") }
        }
        nc.addView(warmthSeek, LinearLayout.LayoutParams(MATCH, WRAP))
        val tintRow = equalRow()
        for (i in TINTS.indices) {
            val b = pill(TINTS[i]) { setTint(i, true) }
            tintButtons.add(b)
            addEqual(tintRow, b)
        }
        nc.addView(tintRow)
        root.addView(nc)

        // Minuterie
        val tc = card()
        tc.addView(label("MINUTERIE", 12f, ACCENT).apply { letterSpacing = 0.2f })
        tc.addView(label("Durée", 16f, Color.WHITE).apply { setPadding(0, dp(8), 0, 0) })
        val durRow = equalRow()
        for (d in DURATIONS) {
            val b = pill("$d min") { setDuration(d) }
            durationButtons.add(b)
            addEqual(durRow, b)
        }
        tc.addView(durRow)
        val timerRow = equalRow()
        addEqual(timerRow, pill("Lancer") {
            queue("timer", "--ei duration $duration --es timer start")
        })
        addEqual(timerRow, pill("Arrêter") { queue("timer", "--es timer stop") })
        tc.addView(timerRow)
        tc.addView(label(
            "Les autres réglages (luminosité finale, volume, courbe…) sont ceux enregistrés sur la TV.",
            13f, MUTED
        ).apply { setPadding(0, dp(10), 0, 0) })
        root.addView(tc)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0B0B0F.toInt())
            addView(root)
        }
        setContentView(scroll)

        setTint(0, false)
        setDuration(30)
        setStatus(
            "Active le débogage ADB sur la Fire Stick, puis entre son adresse IP " +
                "(Paramètres > Ma Fire TV > À propos > Réseau).",
            false
        )
        if (currentHost.isNotEmpty()) connect()
    }

    override fun onDestroy() {
        worker.execute {
            try {
                adb?.close()
            } catch (e: Exception) {
            }
        }
        worker.shutdown()
        super.onDestroy()
    }

    // ---------- Actions ----------

    private fun throttled(final: Boolean, send: () -> Unit) {
        val now = SystemClock.uptimeMillis()
        if (final || now - lastSent > 250) {
            lastSent = now
            send()
        }
    }

    private fun step(d: Int) {
        val b = (brightness + d).coerceIn(5, 100)
        brightness = b
        brightnessText.text = "$b %"
        brightnessSeek.progress = b - 5
        queue("b", "--ei brightness $b")
    }

    private fun setNightChecked(on: Boolean) {
        updating = true
        nightSwitch.isChecked = on
        updating = false
    }

    private fun setTint(i: Int, send: Boolean) {
        tint = i
        for (k in tintButtons.indices) select(tintButtons[k], k == i)
        if (send) {
            setNightChecked(true)
            queue("t", "--ei tint $i --ei night 1")
        }
    }

    private fun setDuration(d: Int) {
        duration = d
        for (k in durationButtons.indices) select(durationButtons[k], DURATIONS[k] == d)
    }

    private fun connect() {
        val host = hostInput.text.toString().trim()
        if (host.isEmpty()) {
            setStatus("Entre l'adresse IP de la Fire Stick.", true)
            return
        }
        getSharedPreferences("remote", MODE_PRIVATE).edit().putString("host", host).apply()
        currentHost = host
        setStatus(
            "Connexion à $host… Si une demande apparaît sur la TV, accepte-la " +
                "(coche « Toujours autoriser »).",
            false
        )
        queue("status", "")
    }

    // ---------- Envoi des commandes (ADB sur le réseau) ----------

    private fun queue(key: String, extras: String) {
        synchronized(pending) {
            pending[key] = extras
            if (running) return
            running = true
        }
        worker.execute { drain() }
    }

    private fun drain() {
        while (true) {
            val cmd = synchronized(pending) {
                if (pending.isEmpty()) {
                    running = false
                    null
                } else {
                    val c = pending.values.joinToString(" ")
                    pending.clear()
                    c
                }
            } ?: return
            run(cmd)
        }
    }

    private fun keyPair(): AdbKeyPair {
        val priv = File(filesDir, "adbkey")
        val pub = File(filesDir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) {
            AdbKeyPair.generate(priv, pub)
        }
        return AdbKeyPair.read(priv, pub)
    }

    private fun connection(host: String): Dadb {
        val cur = adb
        if (cur != null && connectedHost == host) return cur
        try {
            cur?.close()
        } catch (e: Exception) {
        }
        val d = Dadb.create(host, 5555, keyPair())
        adb = d
        connectedHost = host
        return d
    }

    private fun run(extras: String) {
        val host = currentHost
        if (host.isBlank()) {
            ui.post { setStatus("Entre l'adresse IP de la Fire Stick.", true) }
            return
        }
        try {
            val out = connection(host)
                .shell("am broadcast -n com.jp.luminosite/.ControlReceiver $extras").output
            val m = Regex("data=\"([^\"]*)\"").find(out)
            if (m != null) {
                val data = m.groupValues[1]
                ui.post { applyState(host, data) }
            } else {
                ui.post {
                    setStatus(
                        "Connecté, mais l'app Luminosité ne répond pas. Est-elle installée sur la Fire Stick ?",
                        true
                    )
                }
            }
        } catch (e: Exception) {
            adb = null
            connectedHost = null
            val msg = e.message ?: e.javaClass.simpleName
            ui.post {
                setStatus(
                    "Connexion impossible : $msg\nVérifie l'adresse IP, que le débogage ADB est activé, " +
                        "et accepte la demande sur la TV.",
                    true
                )
            }
        }
    }

    private fun applyState(host: String, data: String) {
        val map = HashMap<String, String>()
        for (token in data.split(" ")) {
            val i = token.indexOf('=')
            if (i > 0) map[token.substring(0, i)] = token.substring(i + 1)
        }
        updating = true
        if (!dragging) {
            map["brightness"]?.toIntOrNull()?.let {
                brightness = it
                brightnessText.text = "$it %"
                brightnessSeek.progress = (it - 5).coerceIn(0, 95)
            }
            map["warmth"]?.toIntOrNull()?.let {
                warmthText.text = "Chaleur $it %"
                warmthSeek.progress = ((it / 5) - 1).coerceIn(0, 19)
            }
        }
        map["night"]?.let { nightSwitch.isChecked = it == "1" }
        updating = false
        map["tint"]?.toIntOrNull()?.let { setTint(it.coerceIn(0, TINTS.size - 1), false) }

        val timer = if (map["timer"] == "1") " · minuterie en cours" else ""
        if (data.startsWith("permission")) {
            setStatus(
                "Connecté à $host, mais la permission « afficher par-dessus les autres apps » " +
                    "manque sur la Fire Stick (commande appops).",
                true
            )
        } else {
            setStatus("Connecté à $host$timer", false)
        }
    }
}
