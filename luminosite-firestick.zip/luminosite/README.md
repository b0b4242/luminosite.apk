# Luminosité – Fire TV Stick

Assombrit l'écran avec un filtre noir semi-transparent affiché par-dessus tout.
Réglage de 100 % à 20 % avec les flèches de la télécommande.

## Compiler
1. Dépôt GitHub **public** : envoie ce zip tel quel (sans le décompresser).
2. Le fichier `.github/workflows/build.yml` compile l'APK tout seul.
3. Lien de l'APK : https://github.com/TON_UTILISATEUR/TON_DEPOT/releases/download/latest/luminosite.apk

## Installer
Downloader : entre le lien ci-dessus, puis Installer.
(Si une ancienne version est installée, désinstalle-la d'abord : `pm uninstall com.jp.luminosite`.)

## Activer (une seule fois, via adb)
    appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow

Puis ouvre l'app « Luminosité » et règle avec les flèches.

## Tout remettre à 100 %
Ouvre l'app et monte la luminosité, ou `am force-stop com.jp.luminosite`.
