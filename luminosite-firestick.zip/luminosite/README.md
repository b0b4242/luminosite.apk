# Luminosité – Fire TV Stick

Assombrit l'écran avec un filtre noir semi-transparent (service d'accessibilité).
Réglage de 100 % à 20 % avec les flèches de la télécommande.

## Compiler
1. Crée un dépôt GitHub **public** et envoie-y ce zip tel quel (sans le décompresser).
2. Crée le fichier `.github/workflows/build.yml` avec le code du workflow (fourni dans le chat).
3. Onglet **Actions** : quand le build est vert, l'APK est disponible ici :

       https://github.com/TON_UTILISATEUR/TON_DEPOT/releases/download/latest/luminosite.apk

## Installer
Dans l'app Downloader, entre le lien ci-dessus : le téléchargement démarre tout de suite, puis Installer.

## Activer le service
Ouvre l'app « Luminosité », appuie sur OK pour ouvrir les paramètres d'accessibilité,
puis active « Luminosité ». Si ce menu n'existe pas sur la Fire Stick, via adb :

    adb shell settings put secure enabled_accessibility_services com.jp.luminosite/com.jp.luminosite.DimService
    adb shell settings put secure accessibility_enabled 1

## En cas de problème
Pour tout remettre à 100 % : ouvre l'app et monte la luminosité,
ou `adb shell am force-stop com.jp.luminosite`.
