# Brightness for Fire TV Stick

A small, free app that lets you **dim the screen** on a Fire TV Stick, which has no built-in brightness setting.

It works by drawing a semi-transparent black layer over everything on screen. Use the D-pad on the remote to change the level:

- **Right / Up**: brighter
- **Left / Down**: darker

The level goes from 100 % down to 20 % in steps of 5 %, and is restored automatically after a reboot.

> Not affiliated with or endorsed by Amazon. Fire TV is a trademark of Amazon.com, Inc.

## Install

1. On the Fire Stick, install the **Downloader** app and allow it to install unknown apps.
2. In Downloader, enter this link:

   `https://github.com/B0b4242/luminosite.apk/releases/download/latest/luminosite.apk`

3. Install the APK.

## One-time setup (ADB)

The app needs the "display over other apps" permission. Fire OS has no screen to grant it, so it is given once with ADB:

1. On the Fire Stick: **Settings → My Fire TV → Developer Options → ADB debugging: ON**.
2. Find its IP address in **Settings → My Fire TV → About → Network**.
3. From a computer (or Termux on a phone) run:

   ```
   adb connect FIRE_STICK_IP:5555
   adb shell appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow
   ```

4. Open the **Brightness** app and use the D-pad.

## Limits

- It can only dim, not go brighter than the TV's own maximum.
- Some streaming apps draw video on a hardware layer, which the overlay may not cover: the interface gets darker but not always the picture.
- Tested on a Fire TV Stick 4K (Fire OS 6). Other models may behave differently.

## Uninstall

Remove it like any other app (**Settings → Applications → Manage installed applications**), or with `adb shell pm uninstall com.jp.luminosite`.

## Privacy

The app has no internet permission and collects no data.

## Source code

The full Android project is in `luminosite-firestick.zip`. A GitHub Actions workflow unpacks it and builds the APK automatically on every push to `main`.

## License

MIT, see [LICENSE](LICENSE).
