# Brightness control for Fire TV Stick

The Fire TV Stick has no built-in brightness setting, so this small free app dims the screen with a semi-transparent black overlay.

> The app's interface is in French, but here are the controls:
>
> - **UP / RIGHT** = brighter, **DOWN / LEFT** = darker (1% per press, hold to go faster)
> - **OK** = night mode on/off (warm orange tint)
> - **Menu (≡)** = settings: night mode intensity and sleep timer options
> - **Play/Pause** = start/stop the sleep timer
> - Any other button closes the app (your setting stays active)

Brightness goes from 100% down to 5%. It can't go above your TV's maximum brightness, since it only dims.

## Themes

Seven color themes (classic, ocean, forest, aurora, rose, sunset, pure black) in the settings (Menu > Thème). Night mode always keeps its warm amber look.

## Night mode

Adds a warm tint on top of the dimming. In the settings (Menu) you can choose the warmth (5% to 100%) and the tint: amber, sepia, red or honey.

## Sleep timer

Gradually lowers the screen brightness (and optionally the volume) over time. In the settings you can choose:

- duration (5 min to 3 h) and an optional delay before it starts
- final brightness, and final volume (or leave the volume untouched)
- curve: how the drop is shaped over time (linear, smooth, very smooth, slow start, very slow start, fast start, very fast start, or in steps), with a small preview graph
- turn night mode on when it starts
- at the end: do nothing, or pause playback (the volume goes back to its starting level)

The volume fade only affects the Fire Stick's own audio volume, not your TV's volume. Changing the brightness by hand stops the timer.

## Control with adb or scripts

You can control the app from adb, a script, or a macro / home automation app, by sending a broadcast (drop the `adb shell` part if you're already in a shell):

    adb shell am broadcast -n com.jp.luminosite/.ControlReceiver --ei brightness 40

Extras (all optional, combine as you like):

- `--ei brightness 5..100`: set the brightness. `--ei delta 10` / `--ei delta -10`: brighter / darker by 10
- `--ei night 0|1|2`: night mode off / on / toggle
- `--ei warmth 5..100`, `--ei tint 0..3` (amber, sepia, red, honey), `--ei theme 0..6`
- `--es timer start|stop|toggle`: start or stop the sleep timer
- Timer settings: `--ei duration <min>`, `--ei delay <min>`, `--ei final_brightness 5..100`, `--ei final_volume -1..100` (-1 = leave the sound alone), `--ei curve 0..7`, `--ei night_at_start 0|1`, `--ei pause_at_end 0|1`

Example, 30 minute timer fading to 10% brightness and pausing at the end:

    adb shell am broadcast -n com.jp.luminosite/.ControlReceiver --ei brightness 100 --ei duration 30 --ei final_brightness 10 --ei pause_at_end 1 --es timer start

Every command prints the current state (`brightness=... night=... timer=...`), and sending it with no extras just reads the state. Note that any app on the device can send these broadcasts.

## Phone remote app

A second app, **Luminosité TV**, lets you control the Fire Stick app from your phone (Android 8+), over your Wi-Fi.

- Download: `https://github.com/B0b4242/luminosite.apk/releases/download/latest/luminosite-remote.apk`
- It uses ADB over the network, so ADB debugging must stay enabled on the Fire Stick, and the Fire Stick and the phone must be on the same Wi-Fi.
- Enter the Fire Stick's IP address (Settings > My Fire TV > About > Network) and tap Connect. The first time, accept the "Allow USB debugging?" prompt on the TV (tick "Always allow").
- You can then set the brightness, turn night mode on and change its warmth and tint, and start or stop the sleep timer.
- It only controls the dimming done by the Fire Stick app, not your TV's real backlight.

## Setup

1. In **Downloader**, enter this link and install:

   `https://github.com/B0b4242/luminosite.apk/releases/download/latest/luminosite.apk`

2. Enable ADB debugging (**Settings > My Fire TV > Developer options**), connect with adb, and run this once:

   `adb shell appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow`

3. Open the app (it's called **Luminosité** on the home screen) and use the remote. Your setting is restored after a reboot.

## Notes

- Tested on a Fire TV Stick 4K (Fire OS 6.7.1.1).
- Some streaming apps draw video on a hardware layer that may not be dimmed.
- The app has no internet permission and collects no data.
