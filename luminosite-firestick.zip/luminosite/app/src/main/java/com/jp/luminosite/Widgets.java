package com.jp.luminosite;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Vues dessinées à la main : soleil, barre, halo, points d'intensité. */
final class Widgets {

    private Widgets() { }

    static int withAlpha(int color, int a) {
        int alpha = Math.max(0, Math.min(255, a));
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    /** Vue dont la valeur (0 à 1) s'anime en douceur. */
    abstract static class AnimView extends View {
        protected float value = -1f;
        protected boolean night = false;
        private ValueAnimator anim;

        AnimView(Context c) {
            super(c);
        }

        void setNight(boolean n) {
            if (n != night) {
                night = n;
                invalidate();
            }
        }

        void setValue(float v) {
            if (value < 0f) {
                value = v;
                invalidate();
                return;
            }
            if (Math.abs(v - value) < 0.0005f) return;
            if (anim != null) {
                anim.cancel();
            }
            anim = ValueAnimator.ofFloat(value, v);
            anim.setDuration(180);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    value = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        }

        protected float v01() {
            return value < 0f ? 0f : clamp01(value);
        }
    }

    /** Halo de lumière en arrière-plan, plus fort quand la luminosité est haute. */
    static class GlowView extends AnimView {
        private final Paint p = new Paint();

        GlowView(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            int base = night ? 0xFFFF9A3C : 0xFF7A8CFF;
            int a = Math.round(25 + 55 * v01());
            p.setShader(new RadialGradient(w / 2f, h * 0.40f, Math.max(w, h) * 0.6f,
                    withAlpha(base, a), withAlpha(base, 0), Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, p);
        }
    }

    /** Gros soleil dont les rayons s'allongent avec la luminosité. */
    static class HeroIcon extends AnimView {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        HeroIcon(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float b = v01();
            float s = Math.min(getWidth(), getHeight());
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            int base = night ? 0xFFFFB347 : 0xFFFFFFFF;

            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, s * 0.5f,
                    withAlpha(base, Math.round(30 + 90 * b)), withAlpha(base, 0), Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, s * 0.5f, p);
            p.setShader(null);

            float core = s * 0.2f;
            p.setColor(base);
            canvas.drawCircle(cx, cy, core, p);

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(s * 0.045f);
            p.setColor(withAlpha(base, Math.round(70 + 185 * b)));
            float inner = core + s * 0.07f;
            float len = s * 0.03f + s * 0.15f * b;
            for (int i = 0; i < 12; i++) {
                double a = Math.PI / 6 * i;
                float cos = (float) Math.cos(a);
                float sin = (float) Math.sin(a);
                canvas.drawLine(cx + cos * inner, cy + sin * inner,
                        cx + cos * (inner + len), cy + sin * (inner + len), p);
            }
        }
    }

    /** Barre de luminosité style Apple TV. */
    static class BrightnessBar extends AnimView {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final RectF glowRect = new RectF();
        private final Path clip = new Path();
        private final float d;

        BrightnessBar(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            track.setColor(0x26FFFFFF);
            icon.setStrokeCap(Paint.Cap.ROUND);
        }

        private void drawSun(Canvas c, float cx, float cy, float r) {
            icon.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, cy, r, icon);
            icon.setStyle(Paint.Style.STROKE);
            icon.setStrokeWidth(Math.max(2f, r * 0.22f));
            for (int i = 0; i < 8; i++) {
                double a = Math.PI / 4 * i;
                float cos = (float) Math.cos(a);
                float sin = (float) Math.sin(a);
                c.drawLine(cx + cos * r * 1.5f, cy + sin * r * 1.5f,
                        cx + cos * r * 2.0f, cy + sin * r * 2.0f, icon);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float cy = getHeight() / 2f;
            int tint = night ? 0xFFFFB347 : 0xFFFFFFFF;

            icon.setColor(withAlpha(tint, 0xD0));
            drawSun(canvas, 28 * d, cy, 6 * d);
            drawSun(canvas, w - 36 * d, cy, 10 * d);

            float barH = 18 * d;
            float radius = barH / 2f;
            rect.set(72 * d, cy - radius, w - 88 * d, cy + radius);
            canvas.drawRoundRect(rect, radius, radius, track);

            float f = v01();
            float fillRight = Math.max(rect.left + barH, rect.left + rect.width() * f);

            if (f > 0f) {
                glow.setColor(withAlpha(tint, 0x22));
                glowRect.set(rect.left - 3 * d, rect.top - 3 * d, fillRight + 3 * d, rect.bottom + 3 * d);
                canvas.drawRoundRect(glowRect, radius + 3 * d, radius + 3 * d, glow);
            }

            canvas.save();
            clip.reset();
            clip.addRoundRect(rect, radius, radius, Path.Direction.CW);
            canvas.clipPath(clip);
            fill.setShader(new LinearGradient(rect.left, 0, rect.right, 0,
                    night ? 0xFFFFD79A : 0xFFFFFFFF,
                    night ? 0xFFFFA630 : 0xFFD9E0FF,
                    Shader.TileMode.CLAMP));
            canvas.drawRect(rect.left, rect.top, fillRight, rect.bottom, fill);
            fill.setShader(null);
            canvas.restore();
        }
    }

    /** Fine barre de progression (minuterie). */
    static class ThinBar extends AnimView {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();

        ThinBar(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            float r = h / 2f;
            p.setColor(0x22FFFFFF);
            rect.set(0, 0, w, h);
            canvas.drawRoundRect(rect, r, r, p);
            p.setColor(0xFFFFB347);
            rect.set(0, 0, Math.max(h, w * v01()), h);
            canvas.drawRoundRect(rect, r, r, p);
        }
    }

    /** Cinq points qui montrent l'intensité du mode nuit. */
    static class Dots extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private int level = 0;
        private int onColor = 0xFFFFFFFF;
        private int offColor = 0x55FFFFFF;

        Dots(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        void set(int level, int on, int off) {
            this.level = level;
            this.onColor = on;
            this.offColor = off;
            invalidate();
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            setMeasuredDimension(Math.round(64 * d), Math.round(10 * d));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float r = 4 * d;
            float gap = 6 * d;
            for (int i = 0; i < 5; i++) {
                p.setColor(i < level ? onColor : offColor);
                canvas.drawCircle(r + i * (2 * r + gap), getHeight() / 2f, r, p);
            }
        }
    }
}
