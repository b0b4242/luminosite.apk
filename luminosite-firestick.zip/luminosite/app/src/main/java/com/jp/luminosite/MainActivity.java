package com.jp.luminosite;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int MAX_DIM = 95; // luminosité minimale = 5 %

    private SharedPreferences prefs;
    private FrameLayout root;
    private Widgets.GlowView glow;
    private Widgets.HeroIcon hero;
    private Widgets.BrightnessBar bar;
    private Widgets.ThinBar timerBar;
    private Widgets.Dots dots;
    private LinearLayout nightPill;
    private TextView percent;
    private TextView nightLabel;
    private TextView timerChip;
    private TextView status;
    private int dim;
    private boolean night;
    private boolean shownNight;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable uiTick = new Runnable() {
        @Override
        public void run() {
            dim = prefs.getInt(DimService.KEY, 0);
            night = prefs.getBoolean(DimService.NIGHT, false);
            refresh();
            ui.postDelayed(this, 1000);
        }
    };

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        prefs = getSharedPreferences(DimService.PREFS, MODE_PRIVATE);
        dim = prefs.getInt(DimService.KEY, 0);
        night = prefs.getBoolean(DimService.NIGHT, false);
        shownNight = night;

        int screenW = getResources().getDisplayMetrics().widthPixels;

        root = new FrameLayout(this);
        root.setBackground(Ui.screenBg(night));

        glow = new Widgets.GlowView(this);
        root.addView(glow, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        root.addView(content, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView title = Ui.label(this, "LUMINOSITÉ", 14, 0x99FFFFFF);
        title.setLetterSpacing(0.25f);
        content.addView(title);

        // Carte centrale
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(32), dp(20), dp(32), dp(24));
        card.setBackground(Ui.rounded(this, 0x14FFFFFF, 36, 0x1FFFFFFF, 1));

        hero = new Widgets.HeroIcon(this);
        card.addView(hero, new LinearLayout.LayoutParams(dp(84), dp(84)));

        percent = Ui.light(this, "", 68, Color.WHITE);
        card.addView(percent);

        bar = new Widgets.BrightnessBar(this);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        barLp.topMargin = dp(6);
        card.addView(bar, barLp);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                Math.round(screenW * 0.55f), LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.topMargin = dp(16);
        content.addView(card, cardLp);

        // Mode nuit + minuterie
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER);

        nightPill = new LinearLayout(this);
        nightPill.setOrientation(LinearLayout.HORIZONTAL);
        nightPill.setGravity(Gravity.CENTER_VERTICAL);
        nightPill.setPadding(dp(22), dp(10), dp(22), dp(10));
        nightLabel = Ui.label(this, "", 20, Color.WHITE);
        dots = new Widgets.Dots(this);
        LinearLayout.LayoutParams dotsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dotsLp.leftMargin = dp(14);
        nightPill.addView(nightLabel);
        nightPill.addView(dots, dotsLp);
        chips.addView(nightPill);

        timerChip = Ui.label(this, "", 20, 0xFFFFB347);
        timerChip.setPadding(dp(22), dp(10), dp(22), dp(10));
        timerChip.setBackground(Ui.rounded(this, 0x26FFB347, 40));
        LinearLayout.LayoutParams tcLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tcLp.leftMargin = dp(16);
        chips.addView(timerChip, tcLp);

        LinearLayout.LayoutParams chipsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        chipsLp.topMargin = dp(20);
        content.addView(chips, chipsLp);

        timerBar = new Widgets.ThinBar(this);
        LinearLayout.LayoutParams tbLp = new LinearLayout.LayoutParams(Math.round(screenW * 0.3f), dp(4));
        tbLp.topMargin = dp(12);
        content.addView(timerBar, tbLp);

        status = Ui.label(this, "", 18, 0xFFFF6B6B);
        status.setPadding(dp(40), dp(12), dp(40), 0);
        content.addView(status);

        // Rappel des boutons
        LinearLayout hints = new LinearLayout(this);
        hints.setOrientation(LinearLayout.HORIZONTAL);
        hints.setGravity(Gravity.CENTER);
        String[][] keys = {
                {"▲ ▼", "Luminosité"},
                {"OK", "Mode nuit"},
                {"MENU", "Réglages"},
                {"LECTURE", "Minuterie"},
                {"AUTRE", "Quitter"}
        };
        for (int i = 0; i < keys.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.leftMargin = dp(22);
            hints.addView(Ui.keyHint(this, keys[i][0], keys[i][1]), lp);
        }
        LinearLayout.LayoutParams hintsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hintsLp.topMargin = dp(24);
        content.addView(hints, hintsLp);

        setContentView(root);
    }

    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void startDimService() {
        if (canOverlay()) {
            startService(new Intent(this, DimService.class));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startDimService();
        ui.removeCallbacks(uiTick);
        ui.post(uiTick);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(uiTick);
        super.onPause();
    }

    private static String fmt(long ms) {
        long s = (ms + 999) / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) {
            return String.format(Locale.US, "%d:%02d:%02d", h, m, sec);
        }
        return String.format(Locale.US, "%d:%02d", m, sec);
    }

    private void refresh() {
        int brightness = 100 - dim;
        float f = brightness / 100f;

        String num = String.valueOf(brightness);
        SpannableString sp = new SpannableString(num + "%");
        sp.setSpan(new RelativeSizeSpan(0.4f), num.length(), sp.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        percent.setText(sp);

        bar.setNight(night);
        bar.setValue(f);
        hero.setNight(night);
        hero.setValue(f);
        glow.setNight(night);
        glow.setValue(f);
        if (night != shownNight) {
            root.setBackground(Ui.screenBg(night));
            shownNight = night;
        }

        // Pastille mode nuit
        if (night) {
            int lvl = Math.max(1, Math.min(5, prefs.getInt(DimService.NIGHT_LEVEL, 3)));
            nightPill.setBackground(Ui.rounded(this, 0xFFFFB347, 40));
            nightLabel.setTextColor(0xFF2B1600);
            nightLabel.setText("Mode nuit");
            dots.setVisibility(View.VISIBLE);
            dots.set(lvl, 0xFF2B1600, 0x552B1600);
        } else {
            nightPill.setBackground(Ui.rounded(this, 0x1FFFFFFF, 40, 0x1FFFFFFF, 1));
            nightLabel.setTextColor(0xCCFFFFFF);
            nightLabel.setText("Mode nuit : désactivé");
            dots.setVisibility(View.GONE);
        }

        // Minuterie
        if (prefs.getBoolean(DimService.T_ACTIVE, false)) {
            long now = System.currentTimeMillis();
            long startAt = prefs.getLong(DimService.R_START, now) + prefs.getLong(DimService.R_DELAY, 0);
            long total = prefs.getLong(DimService.R_DUR, 0);
            long remaining = Math.max(0, startAt + total - now);
            timerChip.setVisibility(View.VISIBLE);
            timerBar.setVisibility(View.VISIBLE);
            if (now < startAt) {
                timerChip.setText("Début dans " + fmt(startAt - now));
                timerBar.setValue(1f);
            } else {
                timerChip.setText("Minuterie  " + fmt(remaining));
                timerBar.setValue(total > 0 ? remaining / (float) total : 0f);
            }
        } else {
            timerChip.setVisibility(View.GONE);
            timerBar.setVisibility(View.GONE);
        }

        if (canOverlay()) {
            status.setText("");
        } else {
            status.setText("Permission manquante. Dans adb, lance :\n"
                    + "appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow");
        }
    }

    private void change(int delta) {
        if (prefs.getBoolean(DimService.T_ACTIVE, false)) {
            SleepTimer.stop(this); // un réglage manuel arrête la minuterie
        }
        dim = Math.max(0, Math.min(MAX_DIM, dim + delta));
        prefs.edit().putInt(DimService.KEY, dim).apply();
        startDimService();
        refresh();
    }

    private void toggleNight() {
        night = !night;
        prefs.edit().putBoolean(DimService.NIGHT, night).apply();
        startDimService();
        refresh();
    }

    private void toggleTimer() {
        if (prefs.getBoolean(DimService.T_ACTIVE, false)) {
            SleepTimer.stop(this);
        } else {
            SleepTimer.start(this);
        }
        refresh();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int rc = event.getRepeatCount();
        int step = rc < 8 ? 1 : (rc < 24 ? 2 : 5); // 1 % par appui, accélère si on maintient
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_UP:
                change(-step);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                change(step);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (rc == 0) {
                    toggleNight();
                }
                return true;
            case KeyEvent.KEYCODE_MENU:
                if (rc == 0) {
                    startActivity(new Intent(this, SettingsActivity.class));
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (rc == 0) {
                    toggleTimer();
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                return super.onKeyDown(keyCode, event);
            default:
                // Tout autre bouton : on quitte l'app (le filtre reste actif)
                finish();
                return true;
        }
    }
}
