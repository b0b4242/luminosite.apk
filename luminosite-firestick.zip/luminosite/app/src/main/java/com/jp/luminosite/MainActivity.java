package com.jp.luminosite;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int MAX_DIM = 95; // luminosité minimale = 5 %
    private static final int STEP = 5;

    private SharedPreferences prefs;
    private TextView percent;
    private TextView nightPill;
    private TextView status;
    private BrightnessBar bar;
    private int dim;
    private boolean night;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, int color, boolean light) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        if (light) {
            tv.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        }
        return tv;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        prefs = getSharedPreferences(DimService.PREFS, MODE_PRIVATE);
        dim = prefs.getInt(DimService.KEY, 0);
        night = prefs.getBoolean(DimService.NIGHT, false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackground(new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1C1C1E, 0xFF000000}));

        TextView title = text("Luminosité", 26, 0xB3FFFFFF, false);

        percent = text("", 90, Color.WHITE, true);

        int barW = Math.round(getResources().getDisplayMetrics().widthPixels * 0.6f);
        bar = new BrightnessBar(this);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(barW, dp(72));
        barLp.topMargin = dp(16);

        nightPill = text("", 22, Color.WHITE, false);
        nightPill.setPadding(dp(28), dp(10), dp(28), dp(10));
        LinearLayout.LayoutParams pillLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pillLp.topMargin = dp(24);

        status = text("", 20, 0xFFFF6B6B, false);
        status.setPadding(dp(40), dp(16), dp(40), 0);

        TextView hint = text("◀ ▼ plus sombre   ·   ▶ ▲ plus lumineux   ·   OK mode nuit   ·   autre bouton : quitter",
                16, 0x80FFFFFF, false);
        hint.setPadding(dp(40), dp(32), dp(40), 0);

        root.addView(title);
        root.addView(percent);
        root.addView(bar, barLp);
        root.addView(nightPill, pillLp);
        root.addView(status);
        root.addView(hint);
        setContentView(root);
    }

    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void startDimService() {
        if (canOverlay()) {
            startService(new Intent(this, DimService.class));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        startDimService();
    }

    private void refresh() {
        int brightness = 100 - dim;
        percent.setText(brightness + " %");
        bar.setFraction(brightness / 100f);

        GradientDrawable pill = new GradientDrawable();
        pill.setCornerRadius(dp(40));
        if (night) {
            pill.setColor(0xFFFFB347);
            nightPill.setTextColor(0xFF2B1600);
            nightPill.setText("Mode nuit : activé");
        } else {
            pill.setColor(0x26FFFFFF);
            nightPill.setTextColor(0xCCFFFFFF);
            nightPill.setText("Mode nuit : désactivé");
        }
        nightPill.setBackground(pill);

        if (canOverlay()) {
            status.setText("");
        } else {
            status.setText("Permission manquante. Dans adb, lance :\n"
                    + "appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow");
        }
    }

    private void change(int delta) {
        dim = Math.max(0, Math.min(MAX_DIM, dim + delta));
        prefs.edit().putInt(DimService.KEY, dim).apply();
        startDimService();
        refresh();
    }

    private void toggleNight() {
        night = !night;
        prefs.edit().putBoolean(DimService.NIGHT, night).apply();
        startDimService();
        refresh();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_UP:
                change(-STEP);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                change(STEP);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (event.getRepeatCount() == 0) {
                    toggleNight();
                }
                return true;
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                return super.onKeyDown(keyCode, event);
            default:
                // Tout autre bouton : on quitte l'app (le filtre reste actif)
                finish();
                return true;
        }
    }

    /** Barre de luminosité style Apple TV : piste arrondie, remplissage blanc, soleils. */
    private static class BrightnessBar extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final Path clip = new Path();
        private final float density;
        private float fraction = -1f;
        private ValueAnimator anim;

        BrightnessBar(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
            track.setColor(0x33FFFFFF);
            fill.setColor(Color.WHITE);
            icon.setColor(0xD9FFFFFF);
            icon.setStrokeCap(Paint.Cap.ROUND);
        }

        void setFraction(float f) {
            if (fraction < 0f) {
                fraction = f;
                invalidate();
                return;
            }
            if (anim != null) {
                anim.cancel();
            }
            anim = ValueAnimator.ofFloat(fraction, f);
            anim.setDuration(160);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    fraction = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        }

        private void drawSun(Canvas c, float cx, float cy, float r) {
            icon.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, cy, r, icon);
            icon.setStyle(Paint.Style.STROKE);
            icon.setStrokeWidth(Math.max(2f, r * 0.22f));
            for (int i = 0; i < 8; i++) {
                double a = Math.PI / 4 * i;
                float cos = (float) Math.cos(a);
                float sin = (float) Math.sin(a);
                c.drawLine(cx + cos * r * 1.5f, cy + sin * r * 1.5f,
                        cx + cos * r * 2.0f, cy + sin * r * 2.0f, icon);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float cy = getHeight() / 2f;

            drawSun(canvas, 36 * density, cy, 7 * density);
            drawSun(canvas, w - 40 * density, cy, 12 * density);

            float barH = 14 * density;
            float radius = barH / 2f;
            rect.set(84 * density, cy - radius, w - 96 * density, cy + radius);
            canvas.drawRoundRect(rect, radius, radius, track);

            float f = Math.max(0f, Math.min(1f, fraction));
            canvas.save();
            clip.reset();
            clip.addRoundRect(rect, radius, radius, Path.Direction.CW);
            canvas.clipPath(clip);
            canvas.drawRect(rect.left, rect.top, rect.left + rect.width() * f, rect.bottom, fill);
            canvas.restore();
        }
    }
}
