package com.jp.luminosite;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int MAX_DIM = 80; // luminosité minimale = 20 %
    private static final int STEP = 5;

    private SharedPreferences prefs;
    private TextView percent;
    private TextView status;
    private int dim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(DimService.PREFS, MODE_PRIVATE);
        dim = prefs.getInt(DimService.KEY, 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#202020"));

        TextView title = makeText("Luminosité de l'écran", 36);
        percent = makeText("", 96);
        TextView help = makeText("◀ / ▼ : plus sombre     ▶ / ▲ : plus lumineux", 28);
        status = makeText("", 26);

        root.addView(title);
        root.addView(percent);
        root.addView(help);
        root.addView(status);
        setContentView(root);
    }

    private TextView makeText(String text, int sp) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(Color.WHITE);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(40, 20, 40, 20);
        return tv;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private boolean serviceEnabled() {
        String s = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(getPackageName() + "/");
    }

    private void refresh() {
        percent.setText((100 - dim) + " %");
        if (serviceEnabled()) {
            status.setText("");
        } else {
            status.setText("Service désactivé : appuie sur OK pour ouvrir les paramètres d'accessibilité.");
        }
    }

    private void change(int delta) {
        dim = Math.max(0, Math.min(MAX_DIM, dim + delta));
        prefs.edit().putInt(DimService.KEY, dim).apply();
        refresh();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_UP:
                change(-STEP);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                change(STEP);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (!serviceEnabled()) {
                    try {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    } catch (Exception e) {
                        status.setText("Paramètres introuvables : active le service avec adb (voir le README).");
                    }
                }
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
