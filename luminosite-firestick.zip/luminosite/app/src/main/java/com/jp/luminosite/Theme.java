package com.jp.luminosite;

import android.content.SharedPreferences;

/** Thèmes de couleurs. Le mode nuit garde toujours son look ambré. */
final class Theme {

    private Theme() { }

    static final String[] NAMES = {
            "classique", "océan", "forêt", "aurore", "rose", "coucher de soleil", "noir pur"
    };

    private static final int[] FILL_A = {
            0xFFFFFFFF, 0xFFBFF3FF, 0xFFCFFFD9, 0xFFE9D5FF, 0xFFFFD6EC, 0xFFFFE0C2, 0xFFFFFFFF};
    private static final int[] FILL_B = {
            0xFFD9E0FF, 0xFF3CC8F0, 0xFF3DDC84, 0xFFA66BFF, 0xFFFF5FA8, 0xFFFF6B4A, 0xFFBDBDBD};
    private static final int[] GLOW = {
            0xFF7A8CFF, 0xFF29B6F6, 0xFF2ECC71, 0xFF8E5CFF, 0xFFFF4D9A, 0xFFFF7043, 0xFFFFFFFF};
    private static final int[] ACCENT = {
            0xFFFFB347, 0xFF4DD0E1, 0xFF66E08F, 0xFFC49BFF, 0xFFFF7AB8, 0xFFFF8A65, 0xFFFFFFFF};
    private static final int[][] BG = {
            {0xFF181A21, 0xFF0A0B0F, 0xFF000000},
            {0xFF0B2230, 0xFF06121B, 0xFF000000},
            {0xFF0E2318, 0xFF07120C, 0xFF000000},
            {0xFF1B1030, 0xFF0B0716, 0xFF000000},
            {0xFF2B0F1E, 0xFF140812, 0xFF000000},
            {0xFF2A130C, 0xFF140A06, 0xFF000000},
            {0xFF000000, 0xFF000000, 0xFF000000}
    };

    static final int NIGHT_ACCENT = 0xFFFFB347;
    private static final int[] NIGHT_BG = {0xFF241409, 0xFF0E0804, 0xFF000000};

    static int index = 0;

    static void load(SharedPreferences p) {
        index = Math.max(0, Math.min(NAMES.length - 1, p.getInt(DimService.THEME, 0)));
    }

    private static int safe(int i) {
        return Math.max(0, Math.min(NAMES.length - 1, i));
    }

    static int fillA(int i) { return FILL_A[safe(i)]; }
    static int fillB(int i) { return FILL_B[safe(i)]; }
    static int fillA() { return FILL_A[index]; }
    static int fillB() { return FILL_B[index]; }

    static int accent(boolean night) { return night ? NIGHT_ACCENT : ACCENT[index]; }
    static int glow(boolean night) { return night ? 0xFFFF9A3C : GLOW[index]; }
    static int[] bg(boolean night) { return night ? NIGHT_BG : BG[index]; }
}
