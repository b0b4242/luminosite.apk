package com.jp.luminosite;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Petits utilitaires d'interface partagés par les deux écrans. */
final class Ui {

    private Ui() { }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rounded(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable rounded(Context c, int color, float radiusDp, int strokeColor, float strokeDp) {
        GradientDrawable g = rounded(c, color, radiusDp);
        g.setStroke(Math.max(1, dp(c, strokeDp)), strokeColor);
        return g;
    }

    static GradientDrawable screenBg(boolean night) {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                night
                        ? new int[]{0xFF241409, 0xFF0E0804, 0xFF000000}
                        : new int[]{0xFF181A21, 0xFF0A0B0F, 0xFF000000});
    }

    static TextView label(Context c, String s, int sp, int color) {
        TextView tv = new TextView(c);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    static TextView light(Context c, String s, int sp, int color) {
        TextView tv = label(c, s, sp, color);
        tv.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        return tv;
    }

    /** Petit bouton de télécommande + son rôle, ex. [OK] Mode nuit. */
    static LinearLayout keyHint(Context c, String key, String text) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView k = label(c, key, 13, Color.WHITE);
        k.setTypeface(Typeface.DEFAULT_BOLD);
        k.setPadding(dp(c, 9), dp(c, 3), dp(c, 9), dp(c, 3));
        k.setBackground(rounded(c, 0x2EFFFFFF, 8));

        TextView t = label(c, text, 14, 0x99FFFFFF);
        t.setPadding(dp(c, 8), 0, 0, 0);

        row.addView(k);
        row.addView(t);
        return row;
    }
}
