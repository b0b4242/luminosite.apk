package com.jp.luminosite;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int level = context.getSharedPreferences(DimService.PREFS, Context.MODE_PRIVATE)
                .getInt(DimService.KEY, 0);
        boolean allowed = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context);
        if (level > 0 && allowed) {
            try {
                context.startService(new Intent(context, DimService.class));
            } catch (Exception ignored) { }
        }
    }
}
