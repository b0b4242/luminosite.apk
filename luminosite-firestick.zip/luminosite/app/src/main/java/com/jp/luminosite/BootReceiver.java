package com.jp.luminosite;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences(DimService.PREFS, Context.MODE_PRIVATE);
        boolean active = prefs.getInt(DimService.KEY, 0) > 0 || prefs.getBoolean(DimService.NIGHT, false);
        boolean allowed = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context);
        if (active && allowed) {
            try {
                context.startService(new Intent(context, DimService.class));
            } catch (Exception ignored) { }
        }
    }
}
