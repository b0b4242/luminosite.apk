package com.jp.luminosite;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {

    private static class Row {
        final String label;
        final String key;
        final int[] values;
        final String[] labels;
        final int def;
        final boolean action;
        LinearLayout box;
        TextView labelView;
        TextView valueView;

        Row(String label, String key, int[] values, String[] labels, int def) {
            this.label = label;
            this.key = key;
            this.values = values;
            this.labels = labels;
            this.def = def;
            this.action = false;
        }

        Row() {
            this.label = null;
            this.key = null;
            this.values = null;
            this.labels = null;
            this.def = 0;
            this.action = true;
        }
    }

    private SharedPreferences prefs;
    private final List<Row> rows = new ArrayList<Row>();
    private int selected = 0;
    private ScrollView scroll;
    private TextView footer;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static int[] range(int from, int to, int step) {
        int n = (to - from) / step + 1;
        int[] r = new int[n];
        for (int i = 0; i < n; i++) {
            r[i] = from + i * step;
        }
        return r;
    }

    private static String[] withSuffix(int[] v, String s) {
        String[] r = new String[v.length];
        for (int i = 0; i < v.length; i++) {
            r[i] = v[i] + s;
        }
        return r;
    }

    private TextView text(int sp, int color) {
        TextView tv = new TextView(this);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        return tv;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        prefs = getSharedPreferences(DimService.PREFS, MODE_PRIVATE);

        int[] bright = range(5, 100, 5);
        int[] vol = new int[22];
        String[] volLabels = new String[22];
        vol[0] = -1;
        volLabels[0] = "désactivé";
        for (int i = 1; i < 22; i++) {
            vol[i] = (i - 1) * 5;
            volLabels[i] = vol[i] + " %";
        }

        rows.add(new Row("Intensité du mode nuit", DimService.NIGHT_LEVEL,
                new int[]{1, 2, 3, 4, 5},
                new String[]{"1 · léger", "2", "3 · moyen", "4", "5 · fort"}, 3));
        rows.add(new Row("Durée de la minuterie", DimService.T_DUR,
                new int[]{5, 10, 15, 20, 30, 45, 60, 90, 120, 180},
                new String[]{"5 min", "10 min", "15 min", "20 min", "30 min", "45 min",
                        "1 h", "1 h 30", "2 h", "3 h"}, 30));
        rows.add(new Row("Délai avant le début", DimService.T_DELAY,
                new int[]{0, 5, 10, 15, 30, 60},
                new String[]{"aucun", "5 min", "10 min", "15 min", "30 min", "1 h"}, 0));
        rows.add(new Row("Luminosité finale", DimService.T_BRIGHT, bright, withSuffix(bright, " %"), 10));
        rows.add(new Row("Volume final", DimService.T_VOL, vol, volLabels, -1));
        rows.add(new Row("Courbe de baisse", DimService.T_CURVE,
                new int[]{0, 1}, new String[]{"linéaire", "douce"}, 0));
        rows.add(new Row("Mode nuit au départ", DimService.T_NIGHT,
                new int[]{0, 1}, new String[]{"non", "oui"}, 0));
        rows.add(new Row("À la fin", DimService.T_END,
                new int[]{0, 1}, new String[]{"ne rien faire", "mettre en pause"}, 0));
        rows.add(new Row());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackground(new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1C1C1E, 0xFF000000}));

        TextView title = text(30, Color.WHITE);
        title.setText("Réglages");
        title.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        title.setPadding(0, dp(20), 0, dp(12));
        root.addView(title);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (Row r : rows) {
            r.box = new LinearLayout(this);
            r.box.setOrientation(LinearLayout.HORIZONTAL);
            r.box.setGravity(Gravity.CENTER_VERTICAL);
            r.box.setPadding(dp(24), dp(10), dp(24), dp(10));

            r.labelView = text(20, Color.WHITE);
            r.box.addView(r.labelView, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            r.valueView = text(20, Color.WHITE);
            r.box.addView(r.valueView, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(6);
            list.addView(r.box, lp);
        }

        scroll = new ScrollView(this);
        scroll.setFocusable(false);
        scroll.addView(list);
        int listW = Math.round(getResources().getDisplayMetrics().widthPixels * 0.7f);
        root.addView(scroll, new LinearLayout.LayoutParams(listW, 0, 1f));

        footer = text(15, 0x80FFFFFF);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(30), dp(10), dp(30), dp(14));
        setFooterDefault();
        root.addView(footer);

        setContentView(root);
        refreshRows();
    }

    private void setFooterDefault() {
        footer.setTextColor(0x80FFFFFF);
        footer.setText("▲ ▼ choisir   ·   ◀ ▶ modifier   ·   OK sur la dernière ligne : lancer / arrêter   ·   Retour : fermer\n"
                + "Le volume final agit sur le son de la Fire Stick, pas sur le volume du téléviseur.");
    }

    private int indexOf(Row r) {
        int v = prefs.getInt(r.key, r.def);
        for (int i = 0; i < r.values.length; i++) {
            if (r.values[i] == v) return i;
        }
        return 0;
    }

    private void refreshRows() {
        boolean active = prefs.getBoolean(DimService.T_ACTIVE, false);
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            boolean sel = (i == selected);

            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            g.setColor(sel ? 0x33FFFFFF : 0x00000000);
            r.box.setBackground(g);

            String label;
            String value;
            if (r.action) {
                label = active ? "Arrêter la minuterie" : "Lancer la minuterie";
                value = "OK";
            } else {
                label = r.label;
                value = r.labels[indexOf(r)];
            }
            r.labelView.setText(label);
            r.valueView.setText(sel && !r.action ? "◀  " + value + "  ▶" : value);
            r.labelView.setTextColor(sel ? Color.WHITE : 0xB3FFFFFF);
            r.valueView.setTextColor(sel ? 0xFFFFB347 : 0x80FFFFFF);
        }
    }

    private void move(int dir) {
        selected = Math.max(0, Math.min(rows.size() - 1, selected + dir));
        refreshRows();
        final Row r = rows.get(selected);
        scroll.post(new Runnable() {
            @Override
            public void run() {
                scroll.smoothScrollTo(0, Math.max(0, r.box.getTop() - dp(100)));
            }
        });
    }

    private void changeValue(int dir) {
        Row r = rows.get(selected);
        if (r.action) return;
        int idx = Math.max(0, Math.min(r.values.length - 1, indexOf(r) + dir));
        SharedPreferences.Editor e = prefs.edit();
        e.putInt(r.key, r.values[idx]);
        if (DimService.NIGHT_LEVEL.equals(r.key)) {
            e.putBoolean(DimService.NIGHT, true); // pour voir l'effet tout de suite
        }
        e.apply();
        refreshRows();
    }

    private void press() {
        Row r = rows.get(selected);
        if (!r.action) return;
        if (prefs.getBoolean(DimService.T_ACTIVE, false)) {
            SleepTimer.stop(this);
            refreshRows();
        } else if (SleepTimer.start(this)) {
            finish();
        } else {
            footer.setTextColor(0xFFFF6B6B);
            footer.setText("Permission manquante. Dans adb, lance :\n"
                    + "appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow");
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean mine = code == KeyEvent.KEYCODE_DPAD_UP
                || code == KeyEvent.KEYCODE_DPAD_DOWN
                || code == KeyEvent.KEYCODE_DPAD_LEFT
                || code == KeyEvent.KEYCODE_DPAD_RIGHT
                || code == KeyEvent.KEYCODE_DPAD_CENTER
                || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (mine) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                switch (code) {
                    case KeyEvent.KEYCODE_DPAD_UP:
                        move(-1);
                        break;
                    case KeyEvent.KEYCODE_DPAD_DOWN:
                        move(1);
                        break;
                    case KeyEvent.KEYCODE_DPAD_LEFT:
                        changeValue(-1);
                        break;
                    case KeyEvent.KEYCODE_DPAD_RIGHT:
                        changeValue(1);
                        break;
                    default:
                        if (e.getRepeatCount() == 0) {
                            press();
                        }
                        break;
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
}
