package com.jp.luminosite;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {

    private static class Row {
        final String label;
        final String key;
        final int[] values;
        final String[] labels;
        final int def;
        final boolean action;
        String header;
        boolean slider;
        boolean showCurve;
        boolean showSwatch;
        TextView headerView;
        Widgets.ThinBar bar;
        Widgets.CurveView curveView;
        Widgets.Swatch swatch;
        LinearLayout box;
        TextView labelView;
        TextView valueView;

        Row(String label, String key, int[] values, String[] labels, int def) {
            this.label = label;
            this.key = key;
            this.values = values;
            this.labels = labels;
            this.def = def;
            this.action = false;
        }

        Row() {
            this.label = null;
            this.key = null;
            this.values = null;
            this.labels = null;
            this.def = 0;
            this.action = true;
        }

        Row withHeader(String h) {
            this.header = h;
            return this;
        }

        Row slider() {
            this.slider = true;
            return this;
        }

        Row curve() {
            this.showCurve = true;
            return this;
        }

        Row swatch() {
            this.showSwatch = true;
            return this;
        }
    }

    private SharedPreferences prefs;
    private final List<Row> rows = new ArrayList<Row>();
    private int selected = 0;
    private ScrollView scroll;
    private FrameLayout root;
    private Widgets.GlowView glow;
    private TextView note;

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private static int[] range(int from, int to, int step) {
        int n = (to - from) / step + 1;
        int[] r = new int[n];
        for (int i = 0; i < n; i++) {
            r[i] = from + i * step;
        }
        return r;
    }

    private static String[] withSuffix(int[] v, String s) {
        String[] r = new String[v.length];
        for (int i = 0; i < v.length; i++) {
            r[i] = v[i] + s;
        }
        return r;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        prefs = getSharedPreferences(DimService.PREFS, MODE_PRIVATE);
        Theme.load(prefs);
        boolean night = prefs.getBoolean(DimService.NIGHT, false);

        int[] bright = range(5, 100, 5);
        int[] vol = new int[22];
        String[] volLabels = new String[22];
        vol[0] = -1;
        volLabels[0] = "désactivé";
        for (int i = 1; i < 22; i++) {
            vol[i] = (i - 1) * 5;
            volLabels[i] = vol[i] + " %";
        }

        rows.add(new Row("Thème", DimService.THEME, new int[]{0, 1, 2, 3, 4, 5, 6}, Theme.NAMES, 0)
                .swatch().withHeader("APPARENCE"));
        int[] warmth = range(5, 100, 5);
        rows.add(new Row("Chaleur", DimService.NIGHT_WARMTH, warmth, withSuffix(warmth, " %"), 50)
                .slider().withHeader("MODE NUIT"));
        rows.add(new Row("Teinte", DimService.NIGHT_TINT,
                new int[]{0, 1, 2, 3}, new String[]{"ambre", "sépia", "rouge", "miel"}, 0));
        rows.add(new Row("Durée", DimService.T_DUR,
                new int[]{5, 10, 15, 20, 30, 45, 60, 90, 120, 180},
                new String[]{"5 min", "10 min", "15 min", "20 min", "30 min", "45 min",
                        "1 h", "1 h 30", "2 h", "3 h"}, 30).withHeader("MINUTERIE"));
        rows.add(new Row("Délai avant le début", DimService.T_DELAY,
                new int[]{0, 5, 10, 15, 30, 60},
                new String[]{"aucun", "5 min", "10 min", "15 min", "30 min", "1 h"}, 0));
        rows.add(new Row("Luminosité finale", DimService.T_BRIGHT, bright, withSuffix(bright, " %"), 10).slider());
        rows.add(new Row("Volume final", DimService.T_VOL, vol, volLabels, -1).slider());
        rows.add(new Row("Courbe de baisse", DimService.T_CURVE,
                new int[]{0, 1, 2, 3, 4, 5, 6, 7},
                new String[]{"linéaire", "douce", "très douce", "lente au début", "très lente au début",
                        "rapide au début", "très rapide au début", "par paliers"}, 0).curve());
        rows.add(new Row("Mode nuit au départ", DimService.T_NIGHT,
                new int[]{0, 1}, new String[]{"non", "oui"}, 0));
        rows.add(new Row("À la fin", DimService.T_END,
                new int[]{0, 1}, new String[]{"ne rien faire", "mettre en pause"}, 0));
        rows.add(new Row());

        int screenW = getResources().getDisplayMetrics().widthPixels;

        root = new FrameLayout(this);
        root.setBackground(Ui.screenBg(night));

        glow = new Widgets.GlowView(this);
        glow.setNight(night);
        glow.setValue(0.5f);
        root.addView(glow, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(content, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView title = Ui.light(this, "Réglages", 32, Color.WHITE);
        title.setPadding(0, dp(22), 0, 0);
        content.addView(title);

        // Liste dans une carte
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (Row r : rows) {
            if (r.header != null) {
                TextView h = Ui.label(this, r.header, 13, 0xB3FFB347);
                h.setLetterSpacing(0.2f);
                h.setGravity(Gravity.START);
                h.setPadding(dp(22), dp(14), 0, dp(6));
                r.headerView = h;
                list.addView(h);
            }

            r.box = new LinearLayout(this);
            r.box.setOrientation(LinearLayout.HORIZONTAL);
            r.box.setGravity(Gravity.CENTER_VERTICAL);
            r.box.setPadding(dp(22), dp(11), dp(22), dp(11));

            r.labelView = Ui.label(this, "", 20, Color.WHITE);
            r.labelView.setGravity(Gravity.START);
            r.box.addView(r.labelView, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            if (r.slider) {
                r.bar = new Widgets.ThinBar(this);
                LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(150), dp(6));
                bl.rightMargin = dp(18);
                r.box.addView(r.bar, bl);
            }

            if (r.showCurve) {
                r.curveView = new Widgets.CurveView(this);
                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                cl.rightMargin = dp(18);
                r.box.addView(r.curveView, cl);
            }
            if (r.showSwatch) {
                r.swatch = new Widgets.Swatch(this);
                LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                sl.rightMargin = dp(14);
                r.box.addView(r.swatch, sl);
            }

            r.valueView = Ui.label(this, "", 20, Color.WHITE);
            r.box.addView(r.valueView, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(3);
            lp.bottomMargin = dp(3);
            if (r.action) {
                lp.topMargin = dp(16);
            }
            list.addView(r.box, lp);
        }

        scroll = new ScrollView(this);
        scroll.setFocusable(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(list);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(6), dp(14), dp(14));
        card.setBackground(Ui.rounded(this, 0x14FFFFFF, 30, 0x1FFFFFFF, 1));
        card.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                Math.round(screenW * 0.6f), 0, 1f);
        cardLp.topMargin = dp(14);
        cardLp.bottomMargin = dp(10);
        content.addView(card, cardLp);

        // Rappel des boutons + note
        LinearLayout hints = new LinearLayout(this);
        hints.setOrientation(LinearLayout.HORIZONTAL);
        hints.setGravity(Gravity.CENTER);
        String[][] keys = {
                {"▲ ▼", "Choisir"},
                {"◀ ▶", "Modifier"},
                {"OK", "Lancer / arrêter"},
                {"RETOUR", "Fermer"}
        };
        for (int i = 0; i < keys.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.leftMargin = dp(22);
            hints.addView(Ui.keyHint(this, keys[i][0], keys[i][1]), lp);
        }
        content.addView(hints);

        note = Ui.label(this, "", 13, 0x66FFFFFF);
        note.setPadding(dp(30), dp(8), dp(30), dp(14));
        setNoteDefault();
        content.addView(note);

        setContentView(root);
        refreshRows();
    }

    private void setNoteDefault() {
        note.setTextColor(0x66FFFFFF);
        note.setText("Le volume final agit sur le son de la Fire Stick, pas sur celui du téléviseur.");
    }

    private int indexOf(Row r) {
        int v = prefs.getInt(r.key, r.def);
        for (int i = 0; i < r.values.length; i++) {
            if (r.values[i] == v) return i;
        }
        return 0;
    }

    private void refreshRows() {
        boolean active = prefs.getBoolean(DimService.T_ACTIVE, false);
        boolean night = prefs.getBoolean(DimService.NIGHT, false);
        int accent = Theme.accent(night);
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            boolean sel = (i == selected);

            String label;
            String value;
            if (r.action) {
                label = active ? "Arrêter la minuterie" : "Lancer la minuterie";
                value = "OK";
                r.box.setBackground(Ui.rounded(this, sel ? accent : Widgets.withAlpha(accent, 0x33), 22));
                r.labelView.setTextColor(sel ? 0xFF14110D : accent);
                r.valueView.setTextColor(sel ? 0xFF14110D : accent);
            } else {
                label = r.label;
                value = r.labels[indexOf(r)];
                if (sel) {
                    r.box.setBackground(Ui.rounded(this, 0x2EFFFFFF, 18, 0x4DFFFFFF, 1));
                    value = "◀   " + value + "   ▶";
                } else {
                    r.box.setBackground(Ui.rounded(this, 0x00000000, 18));
                }
                r.labelView.setTextColor(sel ? Color.WHITE : 0xB3FFFFFF);
                r.valueView.setTextColor(sel ? Color.WHITE : 0x80FFFFFF);
                if (r.slider) {
                    r.bar.setNight(night);
                    r.bar.setValue(Math.max(0, r.values[indexOf(r)]) / 100f);
                }
                if (r.showCurve) {
                    r.curveView.setNight(night);
                    r.curveView.setType(r.values[indexOf(r)]);
                }
                if (r.showSwatch) {
                    r.swatch.set(r.values[indexOf(r)]);
                }
            }
            r.labelView.setText(label);
            r.valueView.setText(value);
            if (r.headerView != null) {
                r.headerView.setTextColor(Widgets.withAlpha(accent, 0xB3));
            }

            float s = sel ? 1.02f : 1f;
            r.box.animate().scaleX(s).scaleY(s).setDuration(120).start();
        }
    }

    private void move(int dir) {
        selected = Math.max(0, Math.min(rows.size() - 1, selected + dir));
        refreshRows();
        final Row r = rows.get(selected);
        scroll.post(new Runnable() {
            @Override
            public void run() {
                scroll.smoothScrollTo(0, Math.max(0, r.box.getTop() - dp(120)));
            }
        });
    }

    private void changeValue(int dir) {
        Row r = rows.get(selected);
        if (r.action) return;
        int idx = Math.max(0, Math.min(r.values.length - 1, indexOf(r) + dir));
        SharedPreferences.Editor e = prefs.edit();
        e.putInt(r.key, r.values[idx]);
        if (DimService.NIGHT_WARMTH.equals(r.key) || DimService.NIGHT_TINT.equals(r.key)) {
            e.putBoolean(DimService.NIGHT, true); // pour voir l'effet tout de suite
        }
        e.apply();
        Theme.load(prefs);
        boolean n = prefs.getBoolean(DimService.NIGHT, false);
        root.setBackground(Ui.screenBg(n));
        glow.setNight(n);
        glow.invalidate();
        refreshRows();
    }

    private void press() {
        Row r = rows.get(selected);
        if (!r.action) return;
        if (prefs.getBoolean(DimService.T_ACTIVE, false)) {
            SleepTimer.stop(this);
            refreshRows();
        } else if (SleepTimer.start(this)) {
            finish();
        } else {
            note.setTextColor(0xFFFF6B6B);
            note.setText("Permission manquante. Dans adb, lance :\n"
                    + "appops set com.jp.luminosite SYSTEM_ALERT_WINDOW allow");
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean mine = code == KeyEvent.KEYCODE_DPAD_UP
                || code == KeyEvent.KEYCODE_DPAD_DOWN
                || code == KeyEvent.KEYCODE_DPAD_LEFT
                || code == KeyEvent.KEYCODE_DPAD_RIGHT
                || code == KeyEvent.KEYCODE_DPAD_CENTER
                || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (mine) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                switch (code) {
                    case KeyEvent.KEYCODE_DPAD_UP:
                        move(-1);
                        break;
                    case KeyEvent.KEYCODE_DPAD_DOWN:
                        move(1);
                        break;
                    case KeyEvent.KEYCODE_DPAD_LEFT:
                        changeValue(-1);
                        break;
                    case KeyEvent.KEYCODE_DPAD_RIGHT:
                        changeValue(1);
                        break;
                    default:
                        if (e.getRepeatCount() == 0) {
                            press();
                        }
                        break;
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
}
