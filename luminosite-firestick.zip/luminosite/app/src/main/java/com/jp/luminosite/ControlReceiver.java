package com.jp.luminosite;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

/**
 * Contrôle par adb / scripts / apps de macros :
 * adb shell am broadcast -n com.jp.luminosite/.ControlReceiver --ei brightness 40
 */
public class ControlReceiver extends BroadcastReceiver {

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static String status(SharedPreferences p) {
        return "brightness=" + (100 - p.getInt(DimService.KEY, 0))
                + " night=" + (p.getBoolean(DimService.NIGHT, false) ? 1 : 0)
                + " warmth=" + p.getInt(DimService.NIGHT_WARMTH, 50)
                + " tint=" + p.getInt(DimService.NIGHT_TINT, 0)
                + " theme=" + p.getInt(DimService.THEME, 0)
                + " timer=" + (p.getBoolean(DimService.T_ACTIVE, false) ? 1 : 0);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        SharedPreferences p = c.getSharedPreferences(DimService.PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor e = p.edit();
        boolean manual = false;

        // Luminosité (5 à 100) ou changement relatif (delta positif = plus lumineux)
        if (i.hasExtra("brightness")) {
            int b = clamp(i.getIntExtra("brightness", 100), 5, 100);
            e.putInt(DimService.KEY, 100 - b);
            manual = true;
        } else if (i.hasExtra("delta")) {
            int dim = clamp(p.getInt(DimService.KEY, 0) - i.getIntExtra("delta", 0), 0, 95);
            e.putInt(DimService.KEY, dim);
            manual = true;
        }

        // Mode nuit : 0 = désactivé, 1 = activé, 2 = inverser
        if (i.hasExtra("night")) {
            int n = i.getIntExtra("night", 0);
            boolean cur = p.getBoolean(DimService.NIGHT, false);
            e.putBoolean(DimService.NIGHT, n == 2 ? !cur : n == 1);
        }
        if (i.hasExtra("warmth")) {
            e.putInt(DimService.NIGHT_WARMTH, clamp(i.getIntExtra("warmth", 50), 5, 100));
        }
        if (i.hasExtra("tint")) {
            e.putInt(DimService.NIGHT_TINT, clamp(i.getIntExtra("tint", 0), 0, 3));
        }
        if (i.hasExtra("theme")) {
            e.putInt(DimService.THEME, clamp(i.getIntExtra("theme", 0), 0, 6));
        }

        // Réglages de la minuterie
        if (i.hasExtra("duration")) {
            e.putInt(DimService.T_DUR, clamp(i.getIntExtra("duration", 30), 1, 600));
        }
        if (i.hasExtra("delay")) {
            e.putInt(DimService.T_DELAY, clamp(i.getIntExtra("delay", 0), 0, 600));
        }
        if (i.hasExtra("final_brightness")) {
            e.putInt(DimService.T_BRIGHT, clamp(i.getIntExtra("final_brightness", 10), 5, 100));
        }
        if (i.hasExtra("final_volume")) {
            e.putInt(DimService.T_VOL, clamp(i.getIntExtra("final_volume", -1), -1, 100));
        }
        if (i.hasExtra("curve")) {
            e.putInt(DimService.T_CURVE, clamp(i.getIntExtra("curve", 0), 0, 7));
        }
        if (i.hasExtra("night_at_start")) {
            e.putInt(DimService.T_NIGHT, clamp(i.getIntExtra("night_at_start", 0), 0, 1));
        }
        if (i.hasExtra("pause_at_end")) {
            e.putInt(DimService.T_END, clamp(i.getIntExtra("pause_at_end", 0), 0, 1));
        }

        // Un réglage manuel de la luminosité arrête la minuterie en cours
        if (manual && p.getBoolean(DimService.T_ACTIVE, false)) {
            e.putBoolean(DimService.T_ACTIVE, false);
        }
        e.apply();

        // Minuterie : start / stop / toggle
        String timer = i.getStringExtra("timer");
        if (timer != null) {
            boolean active = p.getBoolean(DimService.T_ACTIVE, false);
            if ("start".equals(timer) || ("toggle".equals(timer) && !active)) {
                SleepTimer.start(c);
            } else if ("stop".equals(timer) || "toggle".equals(timer)) {
                SleepTimer.stop(c);
            }
        }

        // S'assure que le filtre tourne
        boolean allowed = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
        if (allowed) {
            try {
                c.startService(new Intent(c, DimService.class));
            } catch (Exception ignored) { }
        }

        if (isOrderedBroadcast()) {
            setResultData(allowed ? status(p) : "permission manquante (SYSTEM_ALERT_WINDOW) " + status(p));
        }
    }
}
