package com.jp.luminosite;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;

public class DimService extends Service
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    static final String PREFS = "dim";
    static final String KEY = "level";             // 0 à 95 = % d'assombrissement
    static final String NIGHT = "night";           // mode nuit (filtre chaud)
    static final String NIGHT_LEVEL = "night_level"; // intensité 1 à 5

    // Réglages de la minuterie
    static final String T_DUR = "t_dur";           // durée en minutes
    static final String T_DELAY = "t_delay";       // délai avant le début en minutes
    static final String T_BRIGHT = "t_bright";     // luminosité finale en %
    static final String T_VOL = "t_vol";           // volume final en % (-1 = désactivé)
    static final String T_CURVE = "t_curve";       // 0 linéaire, 1 douce
    static final String T_NIGHT = "t_night";       // 1 = mode nuit au départ
    static final String T_END = "t_end";           // 1 = pause à la fin
    static final String T_ACTIVE = "t_active";

    // État d'une minuterie en cours (copie des réglages au démarrage)
    static final String R_START = "r_start";
    static final String R_DELAY = "r_delay";
    static final String R_DUR = "r_dur";
    static final String R_DIM_START = "r_dim_start";
    static final String R_DIM_TARGET = "r_dim_target";
    static final String R_VOL_START = "r_vol_start";
    static final String R_VOL_TARGET = "r_vol_target";
    static final String R_CURVE = "r_curve";
    static final String R_END = "r_end";

    private static final int[] NIGHT_ALPHA = {0, 40, 65, 90, 120, 150};

    private WindowManager wm;
    private OverlayView overlay;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            onTick();
            if (prefs.getBoolean(T_ACTIVE, false)) {
                handler.postDelayed(this, 2000);
            }
        }
    };

    /** Filtre plein écran : noir semi-transparent + teinte chaude en mode nuit. */
    private static class OverlayView extends View {
        int dimAlpha = 0;
        int nightAlpha = 0; // 0 = mode nuit désactivé

        OverlayView(Context c) {
            super(c);
            setWillNotDraw(false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (dimAlpha > 0) {
                canvas.drawColor(Color.argb(dimAlpha, 0, 0, 0));
            }
            if (nightAlpha > 0) {
                canvas.drawColor(Color.argb(nightAlpha, 120, 40, 0));
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.registerOnSharedPreferenceChangeListener(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        overlay = new OverlayView(this);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        try {
            wm.addView(overlay, lp);
        } catch (Exception e) {
            // Permission « afficher par-dessus les autres apps » manquante
            overlay = null;
            stopSelf();
            return;
        }
        apply();
    }

    private void apply() {
        if (overlay == null) return;
        overlay.dimAlpha = Math.round(prefs.getInt(KEY, 0) * 255f / 100f);
        if (prefs.getBoolean(NIGHT, false)) {
            int lvl = Math.max(1, Math.min(5, prefs.getInt(NIGHT_LEVEL, 3)));
            overlay.nightAlpha = NIGHT_ALPHA[lvl];
        } else {
            overlay.nightAlpha = 0;
        }
        overlay.invalidate();
    }

    private void startTicking() {
        handler.removeCallbacks(tick);
        if (prefs.getBoolean(T_ACTIVE, false)) {
            handler.post(tick);
        }
    }

    private void onTick() {
        if (!prefs.getBoolean(T_ACTIVE, false)) return;

        long now = System.currentTimeMillis();
        long start = prefs.getLong(R_START, now);
        long delay = prefs.getLong(R_DELAY, 0);
        long dur = Math.max(1L, prefs.getLong(R_DUR, 1));
        long elapsed = now - start - delay;
        if (elapsed < 0) return; // délai avant le début

        float t = Math.min(1f, elapsed / (float) dur);
        float p = prefs.getInt(R_CURVE, 0) == 1 ? t * t * (3f - 2f * t) : t;

        int d0 = prefs.getInt(R_DIM_START, 0);
        int d1 = prefs.getInt(R_DIM_TARGET, 0);
        int dim = Math.round(d0 + (d1 - d0) * p);
        if (dim != prefs.getInt(KEY, 0)) {
            prefs.edit().putInt(KEY, dim).apply();
        }

        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int vt = prefs.getInt(R_VOL_TARGET, -1);
        if (vt >= 0 && am != null) {
            try {
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int v0 = prefs.getInt(R_VOL_START, 0);
                int v1 = Math.round(vt / 100f * max);
                int v = Math.round(v0 + (v1 - v0) * p);
                if (v != am.getStreamVolume(AudioManager.STREAM_MUSIC)) {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
                }
            } catch (Exception ignored) { }
        }

        if (t >= 1f) {
            endTimer(am, vt);
        }
    }

    private void endTimer(final AudioManager am, int volTarget) {
        prefs.edit().putBoolean(T_ACTIVE, false).apply();
        if (prefs.getInt(R_END, 0) == 1 && am != null) {
            try {
                long ts = SystemClock.uptimeMillis();
                am.dispatchMediaKeyEvent(new KeyEvent(ts, ts, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
                am.dispatchMediaKeyEvent(new KeyEvent(ts, ts, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
            } catch (Exception ignored) { }
            if (volTarget >= 0) {
                final int v0 = prefs.getInt(R_VOL_START, 0);
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, v0, 0);
                        } catch (Exception ignored) { }
                    }
                }, 2000);
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (overlay == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        apply();
        startTicking();
        return START_STICKY;
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        if (KEY.equals(key) || NIGHT.equals(key) || NIGHT_LEVEL.equals(key)) {
            apply();
        } else if (T_ACTIVE.equals(key)) {
            startTicking();
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) { }
            overlay = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
