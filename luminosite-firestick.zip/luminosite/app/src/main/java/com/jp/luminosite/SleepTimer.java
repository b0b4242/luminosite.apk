package com.jp.luminosite;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Build;
import android.provider.Settings;

/** Démarre / arrête la minuterie (baisse progressive de la luminosité et du volume). */
final class SleepTimer {

    private SleepTimer() { }

    static boolean start(Context c) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) {
            return false;
        }
        SharedPreferences p = c.getSharedPreferences(DimService.PREFS, Context.MODE_PRIVATE);
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);

        int bright = p.getInt(DimService.T_BRIGHT, 10);
        int targetDim = Math.max(0, Math.min(95, 100 - bright));

        SharedPreferences.Editor e = p.edit();
        e.putLong(DimService.R_START, System.currentTimeMillis());
        e.putLong(DimService.R_DELAY, p.getInt(DimService.T_DELAY, 0) * 60000L);
        e.putLong(DimService.R_DUR, p.getInt(DimService.T_DUR, 30) * 60000L);
        e.putInt(DimService.R_DIM_START, p.getInt(DimService.KEY, 0));
        e.putInt(DimService.R_DIM_TARGET, targetDim);
        e.putInt(DimService.R_VOL_START, am != null ? am.getStreamVolume(AudioManager.STREAM_MUSIC) : 0);
        e.putInt(DimService.R_VOL_TARGET, p.getInt(DimService.T_VOL, -1));
        e.putInt(DimService.R_CURVE, p.getInt(DimService.T_CURVE, 0));
        e.putInt(DimService.R_END, p.getInt(DimService.T_END, 0));
        if (p.getInt(DimService.T_NIGHT, 0) == 1) {
            e.putBoolean(DimService.NIGHT, true);
        }
        e.putBoolean(DimService.T_ACTIVE, true);
        e.apply();

        c.startService(new Intent(c, DimService.class));
        return true;
    }

    static void stop(Context c) {
        c.getSharedPreferences(DimService.PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(DimService.T_ACTIVE, false).apply();
    }
}
